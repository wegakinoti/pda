/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pushdownautomata;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.*;

/**
 *
 * @author Wega Kinoti
 */
public class PushdownAutomata {
   static String startState; 
   static PushdownAutomata pda = new PushdownAutomata();
   static ArrayList<String> acceptStates = new ArrayList<>();
   static ArrayList<String> pdaFile = new ArrayList<>();
   static ArrayList<Character> alphabet = new ArrayList<>();
   static ArrayList<Character> stackAlphabet = new ArrayList<>();
   static ArrayList<Transition> transitions = new ArrayList<>();
   static Stack<Character> pdaStack = new Stack<>();
   
  
   
   public static void fileChooser(){
      System.out.println("Please choose file containing PDA");
      JFileChooser fileChooser = new JFileChooser();
      fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
      int selection = fileChooser.showOpenDialog(null);
      if(selection == JFileChooser.APPROVE_OPTION){
         File selected = fileChooser.getSelectedFile();
         System.out.println("User picked file: " + selected.getAbsolutePath());
         try{
            Scanner scan = new Scanner(selected);
            while (scan.hasNextLine()){
               pdaFile.add(scan.nextLine());
            }
            scan.close();
         } 
         catch (FileNotFoundException e){
            System.out.println("Error");
         } 
      }
   }
   
   public static ArrayList<String> acceptStates(){
      startState = pdaFile.get(0);
      String [] accept = pdaFile.get(1).split(" ");
      acceptStates = new ArrayList<>(Arrays.asList(accept));
      System.out.println("Accept States: " + acceptStates);
      return acceptStates;
   }
   
   public static ArrayList<Transition> transitions(){
      for (int i = 2 ; i < pdaFile.size(); i++){
         String [] data = pdaFile.get(i).split(" ");
         char label = data[1].charAt(1);
         char pop = data[2].charAt(0);
         char push = data[3].charAt(0);
         
         Transition transition = new Transition(data[0], label, pop, push, data[4]);
         transitions.add(transition);
         pda.setTransitions(transitions);
      }
      return transitions;
   }
   
   public void setTransitions(ArrayList<Transition> transitions) {
        pda.transitions = transitions;
    } 
   
   public static ArrayList<Character> alphabet(){
      for(int i = 2; i < pdaFile.size(); i++){
         String [] data = pdaFile.get(i).split(" ");
         char letter = data[1].charAt(1); 
         if(!alphabet.contains(letter) && letter != 'e'){
            alphabet.add(letter);
         }
      }
      System.out.println("Alphabet is: " + alphabet);
      for(int i = 2; i < pdaFile.size(); i++){
         String [] data = pdaFile.get(i).split(" ");
         char letter = data[2].charAt(0); 
         if(!stackAlphabet.contains(letter) && (letter != 'e')){
               stackAlphabet.add(letter);
            
         }
      }
      System.out.println("Stack Alphabet is: " + stackAlphabet);
      
      return alphabet;
   }
   public static boolean acceptInput(String userInput){ 
        Transition jump;
        String current = startState;
        String next;
        
        for (int i = 0; i < userInput.length(); i++) {
            char label = userInput.charAt(i);
            for (int j = 0; j < transitions.size(); j++) {
                jump = transitions.get(j);
                if(current.contains(jump.getFromState()) && (label == jump.getInputSymbole())){
                   current = jump.getToState();
                   System.out.println(jump.getStackPush());
                   if(!(pdaStack.isEmpty()) && (jump.getStackPull() != 'e')){
                      pdaStack.pop();
                      
                   } else{
                      pdaStack.push(jump.getStackPush());
                      
                   }
                }
            }
        }
       return acceptStates.contains(current) && pdaStack.isEmpty();
   }
   
   /**
    * @param args the command line arguments
    */
   public static void main(String[] args) {
     fileChooser();
     acceptStates();
     transitions();
     alphabet();
     
     String userInput = JOptionPane.showInputDialog("Please enter a string");
     Boolean accept = acceptInput(userInput); 
     if(accept){
        System.out.println("The String " + userInput + " is accepted");
     }
     else{
        System.out.println("The String " + userInput + " is NOT accepted");
     }
   }
   
}