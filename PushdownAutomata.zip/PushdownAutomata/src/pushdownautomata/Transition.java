/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pushdownautomata;

/**
 *
 * @author wega
 */
public class Transition {
   
   private String fromState;
   private char inputSymbole;
   private char stackPull;
   private char stackPush;
   private String toState;
   
   public Transition(String fromState, char inputSymbole, char stackPull, char stackPush, String toState){
      this.fromState = fromState;
      this.inputSymbole = inputSymbole;
      this.stackPull = stackPull;
      this.stackPush = stackPush;
      this.toState = toState;
   }

   /**
    * @return the fromState
    */
   public String getFromState() {
      return fromState;
   }

   /**
    * @param fromState the fromState to set
    */
   public void setFromState(String fromState) {
      this.fromState = fromState;
   }

   /**
    * @return the inputSymbole
    */
   public char getInputSymbole() {
      return inputSymbole;
   }

   /**
    * @param inputSymbole the inputSymbole to set
    */
   public void setInputSymbole(char inputSymbole) {
      this.inputSymbole = inputSymbole;
   }

   /**
    * @return the stackPull
    */
   public char getStackPull() {
      return stackPull;
   }

   /**
    * @param stackPull the stackPull to set
    */
   public void setStackPull(char stackPull) {
      this.stackPull = stackPull;
   }

   /**
    * @return the stackPush
    */
   public char getStackPush() {
      return stackPush;
   }

   /**
    * @param stackPush the stackPush to set
    */
   public void setStackPush(char stackPush) {
      this.stackPush = stackPush;
   }

   /**
    * @return the toState
    */
   public String getToState() {
      return toState;
   }

   /**
    * @param toState the toState to set
    */
   public void setToState(String toState) {
      this.toState = toState;
   }
   
   
}
